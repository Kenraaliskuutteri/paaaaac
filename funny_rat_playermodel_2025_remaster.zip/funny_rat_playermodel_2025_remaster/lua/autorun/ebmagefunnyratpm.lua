player_manager.AddValidModel( "Funny Rat", "models/ebmage/funnyrat.mdl" )
list.Set( "PlayerOptionsModel", "Funny Rat", "models/ebmage/funnyrat.mdl" )

player_manager.AddValidHands( "Funny Rat", "models/ebmage/funnyratarms.mdl", 0, "00000000" )